/* ============================================================
   English Guru — core-data.js
   Dictionary, lessons, shortcuts, kids content, scenarios
   All content editable from Admin Panel
   ============================================================ */

// ------------------------- DICTIONARY -------------------------
const DEFAULT_DICT = [
  // --- Everyday ---
  {en:"hello", ph:"/həˈloʊ/", bn:"হ্যালো / নমস্কার", pos:"interjection", cat:"Everyday", ex:"Hello, how are you?", exBn:"হ্যালো, কেমন আছো?"},
  {en:"good morning", ph:"/ɡʊd ˈmɔːrnɪŋ/", bn:"শুভ সকাল", pos:"greeting", cat:"Everyday", ex:"Good morning, teacher!", exBn:"শুভ সকাল, স্যার!"},
  {en:"thank you", ph:"/θæŋk juː/", bn:"ধন্যবাদ", pos:"phrase", cat:"Everyday", ex:"Thank you for your help.", exBn:"তোমার সাহায্যের জন্য ধন্যবাদ।"},
  {en:"please", ph:"/pliːz/", bn:"অনুগ্রহ করে", pos:"adverb", cat:"Everyday", ex:"Please sit down.", exBn:"অনুগ্রহ করে বসো।"},
  {en:"sorry", ph:"/ˈsɒri/", bn:"দুঃখিত / মাফ করো", pos:"adjective", cat:"Everyday", ex:"I am sorry for being late.", exBn:"দেরি করার জন্য দুঃখিত।"},
  {en:"water", ph:"/ˈwɔːtər/", bn:"পানি", pos:"noun", cat:"Everyday", ex:"I want to drink water.", exBn:"আমি পানি খেতে চাই।"},
  {en:"food", ph:"/fuːd/", bn:"খাবার", pos:"noun", cat:"Everyday", ex:"The food is delicious.", exBn:"খাবারটা মজাদার।"},
  {en:"friend", ph:"/frend/", bn:"বন্ধু", pos:"noun", cat:"Everyday", ex:"He is my best friend.", exBn:"সে আমার সবচেয়ে ভালো বন্ধু।"},
  {en:"mother", ph:"/ˈmʌðər/", bn:"মা", pos:"noun", cat:"Everyday", ex:"My mother cooks well.", exBn:"আমার মা ভালো রান্না করেন।"},
  {en:"father", ph:"/ˈfɑːðər/", bn:"বাবা", pos:"noun", cat:"Everyday", ex:"My father is a doctor.", exBn:"আমার বাবা একজন ডাক্তার।"},
  {en:"school", ph:"/skuːl/", bn:"স্কুল", pos:"noun", cat:"Everyday", ex:"I go to school every day.", exBn:"আমি প্রতিদিন স্কুলে যাই।"},
  {en:"home", ph:"/hoʊm/", bn:"বাড়ি", pos:"noun", cat:"Everyday", ex:"I am going home now.", exBn:"আমি এখন বাড়ি যাচ্ছি।"},
  {en:"book", ph:"/bʊk/", bn:"বই", pos:"noun", cat:"Everyday", ex:"This book is very interesting.", exBn:"এই বইটা খুব মজার।"},
  {en:"time", ph:"/taɪm/", bn:"সময়", pos:"noun", cat:"Everyday", ex:"What time is it?", exBn:"কয়টা বাজে?"},
  {en:"work", ph:"/wɜːrk/", bn:"কাজ", pos:"noun", cat:"Everyday", ex:"I have a lot of work today.", exBn:"আজ আমার অনেক কাজ।"},
  {en:"love", ph:"/lʌv/", bn:"ভালোবাসা", pos:"noun", cat:"Everyday", ex:"I love my country.", exBn:"আমি আমার দেশকে ভালোবাসি।"},
  {en:"happy", ph:"/ˈhæpi/", bn:"খুশি", pos:"adjective", cat:"Everyday", ex:"I am happy today.", exBn:"আমি আজ খুশি।"},
  {en:"good", ph:"/ɡʊd/", bn:"ভালো", pos:"adjective", cat:"Everyday", ex:"This is a good idea.", exBn:"এটা ভালো একটা আইডিয়া।"},
  {en:"bad", ph:"/bæd/", bn:"খারাপ", pos:"adjective", cat:"Everyday", ex:"The weather is bad today.", exBn:"আজ আবহাওয়া খারাপ।"},
  {en:"beautiful", ph:"/ˈbjuːtɪfl/", bn:"সুন্দর", pos:"adjective", cat:"Everyday", ex:"What a beautiful place!", exBn:"কী সুন্দর জায়গা!"},

  // --- Greetings & courtesy ---
  {en:"goodbye", ph:"/ɡʊdˈbaɪ/", bn:"বিদায় / আসসালামু আলাইকুম", pos:"phrase", cat:"Greetings", ex:"Goodbye, see you tomorrow.", exBn:"বিদায়, আগামীকাল দেখা হবে।"},
  {en:"good night", ph:"/ɡʊd naɪt/", bn:"শুভ রাত্রি", pos:"phrase", cat:"Greetings", ex:"Good night, sleep well.", exBn:"শুভ রাত্রি, ভালো ঘুমাও।"},
  {en:"excuse me", ph:"/ɪkˈskjuːz miː/", bn:"মাফ করবেন", pos:"phrase", cat:"Greetings", ex:"Excuse me, where is the station?", exBn:"মাফ করবেন, স্টেশন কোথায়?"},
  {en:"welcome", ph:"/ˈwelkəm/", bn:"স্বাগতম", pos:"noun", cat:"Greetings", ex:"Welcome to our school.", exBn:"আমাদের স্কুলে স্বাগতম।"},
  {en:"how are you", ph:"/haʊ ɑːr juː/", bn:"কেমন আছো?", pos:"phrase", cat:"Greetings", ex:"Hi! How are you today?", exBn:"হাই! আজ কেমন আছো?"},
  {en:"nice to meet you", ph:"/naɪs tə miːt juː/", bn:"তোমার সাথে পরিচিত হয়ে ভালো লাগলো", pos:"phrase", cat:"Greetings", ex:"Nice to meet you, Mr. Khan.", exBn:"মিস্টার খান, আপনার সাথে পরিচিত হয়ে ভালো লাগলো।"},
  {en:"congratulations", ph:"/kənˌɡrætʃəˈleɪʃənz/", bn:"অভিনন্দন", pos:"noun", cat:"Greetings", ex:"Congratulations on your success!", exBn:"তোমার সফলতার জন্য অভিনন্দন!"},
  {en:"good luck", ph:"/ɡʊd lʌk/", bn:"শুভকামনা", pos:"phrase", cat:"Greetings", ex:"Good luck with your exam!", exBn:"তোমার পরীক্ষার জন্য শুভকামনা!"},

  // --- Family ---
  {en:"brother", ph:"/ˈbrʌðər/", bn:"ভাই", pos:"noun", cat:"Family", ex:"My brother is very tall.", exBn:"আমার ভাই খুব লম্বা।"},
  {en:"sister", ph:"/ˈsɪstər/", bn:"বোন", pos:"noun", cat:"Family", ex:"My sister loves reading.", exBn:"আমার বোন পড়তে ভালোবাসে।"},
  {en:"son", ph:"/sʌn/", bn:"ছেলে সন্তান", pos:"noun", cat:"Family", ex:"Their son is five years old.", exBn:"তাদের ছেলেটি পাঁচ বছরের।"},
  {en:"daughter", ph:"/ˈdɔːtər/", bn:"মেয়ে সন্তান", pos:"noun", cat:"Family", ex:"Her daughter is a student.", exBn:"তার মেয়েটি একজন ছাত্রী।"},
  {en:"family", ph:"/ˈfæməli/", bn:"পরিবার", pos:"noun", cat:"Family", ex:"I love my family.", exBn:"আমি আমার পরিবারকে ভালোবাসি।"},
  {en:"grandmother", ph:"/ˈɡrænmʌðər/", bn:"দাদা/নানার মা, দাদি/নানি", pos:"noun", cat:"Family", ex:"My grandmother tells stories.", exBn:"আমার দাদি গল্প বলেন।"},
  {en:"grandfather", ph:"/ˈɡrænfɑːðər/", bn:"দাদা/নানা", pos:"noun", cat:"Family", ex:"My grandfather walks every morning.", exBn:"আমার দাদা প্রতিদিন সকালে হাঁটেন।"},
  {en:"uncle", ph:"/ˈʌŋkl/", bn:"চাচা/মামা", pos:"noun", cat:"Family", ex:"Uncle, please come in.", exBn:"চাচা, ভিতরে আসুন।"},
  {en:"aunt", ph:"/ænt/", bn:"চাচি/মাসি", pos:"noun", cat:"Family", ex:"My aunt lives in Dhaka.", exBn:"আমার চাচি ঢাকায় থাকেন।"},
  {en:"child", ph:"/tʃaɪld/", bn:"শিশু", pos:"noun", cat:"Family", ex:"The child is playing.", exBn:"শিশুটি খেলছে।"},

  // --- Numbers & time ---
  {en:"one", ph:"/wʌn/", bn:"এক", pos:"number", cat:"Numbers", ex:"I have one brother.", exBn:"আমার এক ভাই আছে।"},
  {en:"two", ph:"/tuː/", bn:"দুই", pos:"number", cat:"Numbers", ex:"Give me two minutes.", exBn:"আমাকে দুই মিনিট দাও।"},
  {en:"three", ph:"/θriː/", bn:"তিন", pos:"number", cat:"Numbers", ex:"Three books are on the table.", exBn:"টেবিলে তিনটা বই আছে।"},
  {en:"ten", ph:"/ten/", bn:"দশ", pos:"number", cat:"Numbers", ex:"The class starts at ten.", exBn:"ক্লাস দশটায় শুরু হয়।"},
  {en:"hundred", ph:"/ˈhʌndrəd/", bn:"শত / একশ", pos:"number", cat:"Numbers", ex:"The shirt costs two hundred taka.", exBn:"শার্টটার দাম দুইশ টাকা।"},
  {en:"today", ph:"/təˈdeɪ/", bn:"আজ", pos:"adverb", cat:"Numbers", ex:"Today is Friday.", exBn:"আজ শুক্রবার।"},
  {en:"tomorrow", ph:"/təˈmɒroʊ/", bn:"আগামীকাল", pos:"adverb", cat:"Numbers", ex:"I will call you tomorrow.", exBn:"আমি আগামীকাল তোমাকে ফোন করবো।"},
  {en:"yesterday", ph:"/ˈjestərdeɪ/", bn:"গতকাল", pos:"adverb", cat:"Numbers", ex:"Yesterday was a holiday.", exBn:"গতকাল ছুটির দিন ছিল।"},
  {en:"morning", ph:"/ˈmɔːrnɪŋ/", bn:"সকাল", pos:"noun", cat:"Numbers", ex:"I study in the morning.", exBn:"আমি সকালে পড়ি।"},
  {en:"night", ph:"/naɪt/", bn:"রাত", pos:"noun", cat:"Numbers", ex:"I sleep at night.", exBn:"আমি রাতে ঘুমাই।"},

  // --- Food & eating ---
  {en:"rice", ph:"/raɪs/", bn:"ভাত", pos:"noun", cat:"Food", ex:"We eat rice at lunch.", exBn:"আমরা দুপুরে ভাত খাই।"},
  {en:"fish", ph:"/fɪʃ/", bn:"মাছ", pos:"noun", cat:"Food", ex:"This fish is fresh.", exBn:"এই মাছটা টাটকা।"},
  {en:"bread", ph:"/bred/", bn:"রুটি/পাউরুটি", pos:"noun", cat:"Food", ex:"I eat bread for breakfast.", exBn:"আমি সকালে রুটি খাই।"},
  {en:"milk", ph:"/mɪlk/", bn:"দুধ", pos:"noun", cat:"Food", ex:"Drink milk every day.", exBn:"প্রতিদিন দুধ খাও।"},
  {en:"tea", ph:"/tiː/", bn:"চা", pos:"noun", cat:"Food", ex:"Father drinks tea in the morning.", exBn:"বাবা সকালে চা খান।"},
  {en:"egg", ph:"/eɡ/", bn:"ডিম", pos:"noun", cat:"Food", ex:"I like boiled eggs.", exBn:"আমি সিদ্ধ ডিম পছন্দ করি।"},
  {en:"fruit", ph:"/fruːt/", bn:"ফল", pos:"noun", cat:"Food", ex:"Eat fruit every day.", exBn:"প্রতিদিন ফল খাও।"},
  {en:"mango", ph:"/ˈmæŋɡoʊ/", bn:"আম", pos:"noun", cat:"Food", ex:"Mango is my favorite fruit.", exBn:"আম আমার প্রিয় ফল।"},
  {en:"hungry", ph:"/ˈhʌŋɡri/", bn:"ক্ষুধার্ত / খিদা পাওয়া", pos:"adjective", cat:"Food", ex:"I am very hungry now.", exBn:"আমার এখন খুব খিদা পেয়েছে।"},
  {en:"delicious", ph:"/dɪˈlɪʃəs/", bn:"সুস্বাদু / মজাদার", pos:"adjective", cat:"Food", ex:"The biryani was delicious.", exBn:"বিরিয়ানিটা মজাদার ছিল।"},

  // --- Travel ---
  {en:"train", ph:"/treɪn/", bn:"ট্রেন", pos:"noun", cat:"Travel", ex:"The train leaves at 8 AM.", exBn:"ট্রেনটা সকাল ৮টায় ছাড়ে।"},
  {en:"bus", ph:"/bʌs/", bn:"বাস", pos:"noun", cat:"Travel", ex:"I take the bus to work.", exBn:"আমি বাসে করে কাজে যাই।"},
  {en:"ticket", ph:"/ˈtɪkɪt/", bn:"টিকেট", pos:"noun", cat:"Travel", ex:"Where can I buy a ticket?", exBn:"টিকেট কোথায় কিনতে পারবো?"},
  {en:"station", ph:"/ˈsteɪʃən/", bn:"স্টেশন", pos:"noun", cat:"Travel", ex:"The station is very crowded.", exBn:"স্টেশনটা খুব ভিড়ে ভরা।"},
  {en:"airport", ph:"/ˈerpɔːrt/", bn:"বিমানবন্দর", pos:"noun", cat:"Travel", ex:"How far is the airport?", exBn:"বিমানবন্দর কত দূরে?"},
  {en:"road", ph:"/roʊd/", bn:"রাস্তা", pos:"noun", cat:"Travel", ex:"This road goes to Dhaka.", exBn:"এই রাস্তা ঢাকায় যায়।"},
  {en:"journey", ph:"/ˈdʒɜːrni/", bn:"যাত্রা", pos:"noun", cat:"Travel", ex:"Have a safe journey!", exBn:"যাত্রা শুভ হোক!"},
  {en:"luggage", ph:"/ˈlʌɡɪdʒ/", bn:"লাগেজ / মালপত্র", pos:"noun", cat:"Travel", ex:"Please take your luggage.", exBn:"অনুগ্রহ করে আপনার লাগেজ নিন।"},
  {en:"hotel", ph:"/hoʊˈtel/", bn:"হোটেল", pos:"noun", cat:"Travel", ex:"The hotel is near the beach.", exBn:"হোটেলটা সমুদ্র সৈকতের কাছে।"},
  {en:"left", ph:"/left/", bn:"বাম", pos:"noun", cat:"Travel", ex:"Turn left at the corner.", exBn:"মোড়ে বামে যান।"},

  // --- Office & study ---
  {en:"study", ph:"/ˈstʌdi/", bn:"পড়াশোনা করা", pos:"verb", cat:"Study & Work", ex:"I study English every day.", exBn:"আমি প্রতিদিন ইংরেজি পড়ি।"},
  {en:"teacher", ph:"/ˈtiːtʃər/", bn:"শিক্ষক", pos:"noun", cat:"Study & Work", ex:"Our teacher is very kind.", exBn:"আমাদের শিক্ষক খুব দয়ালু।"},
  {en:"student", ph:"/ˈstuːdənt/", bn:"ছাত্র/ছাত্রী", pos:"noun", cat:"Study & Work", ex:"She is a good student.", exBn:"সে একজন ভালো ছাত্রী।"},
  {en:"exam", ph:"/ɪɡˈzæm/", bn:"পরীক্ষা", pos:"noun", cat:"Study & Work", ex:"The exam starts on Sunday.", exBn:"পরীক্ষা রবিবার শুরু হবে।"},
  {en:"question", ph:"/ˈkwestʃən/", bn:"প্রশ্ন", pos:"noun", cat:"Study & Work", ex:"Ask me any question.", exBn:"আমাকে যেকোনো প্রশ্ন করো।"},
  {en:"answer", ph:"/ˈænsər/", bn:"উত্তর", pos:"noun", cat:"Study & Work", ex:"Your answer is correct.", exBn:"তোমার উত্তরটি সঠিক।"},
  {en:"office", ph:"/ˈɒfɪs/", bn:"অফিস", pos:"noun", cat:"Study & Work", ex:"I reached the office at 9.", exBn:"আমি ৯টায় অফিসে পৌঁছেছি।"},
  {en:"meeting", ph:"/ˈmiːtɪŋ/", bn:"মিটিং / সভা", pos:"noun", cat:"Study & Work", ex:"The meeting starts at noon.", exBn:"মিটিং দুপুরে শুরু হবে।"},
  {en:"salary", ph:"/ˈsæləri/", bn:"বেতন", pos:"noun", cat:"Study & Work", ex:"He gets a good salary.", exBn:"সে ভালো বেতন পায়।"},
  {en:"interview", ph:"/ˈɪntərvjuː/", bn:"সাক্ষাৎকার / ভাইভা", pos:"noun", cat:"Study & Work", ex:"I have an interview tomorrow.", exBn:"আগামীকাল আমার একটা ভাইভা আছে।"},

  // --- Feelings ---
  {en:"angry", ph:"/ˈæŋɡri/", bn:"রাগান্বিত", pos:"adjective", cat:"Feelings", ex:"Don't be angry with me.", exBn:"আমার প্রতি রাগ করো না।"},
  {en:"sad", ph:"/sæd/", bn:"দুঃখিত / মন খারাপ", pos:"adjective", cat:"Feelings", ex:"Why are you sad?", exBn:"তুমি কেন মন খারাপ করছো?"},
  {en:"tired", ph:"/ˈtaɪərd/", bn:"ক্লান্ত", pos:"adjective", cat:"Feelings", ex:"I am tired after work.", exBn:"কাজের পর আমি ক্লান্ত।"},
  {en:"afraid", ph:"/əˈfreɪd/", bn:"ভয় পাওয়া", pos:"adjective", cat:"Feelings", ex:"Don't be afraid of dogs.", exBn:"কুকুরে ভয় পেয়ো না।"},
  {en:"excited", ph:"/ɪkˈsaɪtɪd/", bn:"উত্তেজিত / আবেগাপ্লুত", pos:"adjective", cat:"Feelings", ex:"I am excited about the trip.", exBn:"ট্রিপ নিয়ে আমি রোমাঞ্চিত।"},
  {en:"proud", ph:"/praʊd/", bn:"গর্বিত", pos:"adjective", cat:"Feelings", ex:"I am proud of you.", exBn:"আমি তোমার উপর গর্ব করি।"},
  {en:"worried", ph:"/ˈwʌrid/", bn:"চিন্তিত", pos:"adjective", cat:"Feelings", ex:"Mother is worried about you.", exBn:"মা তোমার জন্য চিন্তিত।"},
  {en:"surprised", ph:"/sərˈpraɪzd/", bn:"অবাক / বিস্মিত", pos:"adjective", cat:"Feelings", ex:"I was surprised to see him.", exBn:"তাকে দেখে আমি অবাক হয়েছি।"},

  // --- Actions (verbs) ---
  {en:"eat", ph:"/iːt/", bn:"খাওয়া", pos:"verb", cat:"Verbs", ex:"We eat dinner at 9 PM.", exBn:"আমরা রাত ৯টায় ডিনার খাই।"},
  {en:"drink", ph:"/drɪŋk/", bn:"পান করা", pos:"verb", cat:"Verbs", ex:"Drink more water.", exBn:"বেশি পানি পান করো।"},
  {en:"go", ph:"/ɡoʊ/", bn:"যাওয়া", pos:"verb", cat:"Verbs", ex:"Let's go to the market.", exBn:"চলো বাজারে যাই।"},
  {en:"come", ph:"/kʌm/", bn:"আসা", pos:"verb", cat:"Verbs", ex:"Come to my house.", exBn:"আমার বাড়িতে আসো।"},
  {en:"read", ph:"/riːd/", bn:"পড়া", pos:"verb", cat:"Verbs", ex:"Read this book.", exBn:"এই বইটা পড়ো।"},
  {en:"write", ph:"/raɪt/", bn:"লেখা", pos:"verb", cat:"Verbs", ex:"Write your name here.", exBn:"এখানে তোমার নাম লেখো।"},
  {en:"speak", ph:"/spiːk/", bn:"কথা বলা", pos:"verb", cat:"Verbs", ex:"Speak slowly, please.", exBn:"ধীরে কথা বলো, অনুগ্রহ করে।"},
  {en:"listen", ph:"/ˈlɪsən/", bn:"শোনা", pos:"verb", cat:"Verbs", ex:"Listen to your teacher.", exBn:"শিক্ষকের কথা শোনো।"},
  {en:"sleep", ph:"/sliːp/", bn:"ঘুমানো", pos:"verb", cat:"Verbs", ex:"I sleep for eight hours.", exBn:"আমি আট ঘণ্টা ঘুমাই।"},
  {en:"run", ph:"/rʌn/", bn:"দৌড়ানো", pos:"verb", cat:"Verbs", ex:"He can run very fast.", exBn:"সে খুব দ্রুত দৌড়াতে পারে।"},
  {en:"learn", ph:"/lɜːrn/", bn:"শেখা", pos:"verb", cat:"Verbs", ex:"I want to learn English.", exBn:"আমি ইংরেজি শিখতে চাই।"},
  {en:"understand", ph:"/ˌʌndərˈstænd/", bn:"বোঝা", pos:"verb", cat:"Verbs", ex:"I don't understand this word.", exBn:"এই শব্দটা আমি বুঝি না।"},
  {en:"help", ph:"/help/", bn:"সাহায্য করা", pos:"verb", cat:"Verbs", ex:"Can you help me?", exBn:"তুমি কি আমাকে সাহায্য করতে পারো?"},
  {en:"buy", ph:"/baɪ/", bn:"কেনা", pos:"verb", cat:"Verbs", ex:"I want to buy a phone.", exBn:"আমি একটা ফোন কিনতে চাই।"},
  {en:"watch", ph:"/wɒtʃ/", bn:"দেখা (ভিডিও/টিভি)", pos:"verb", cat:"Verbs", ex:"We watch TV at night.", exBn:"আমরা রাতে টিভি দেখি।"},

  // --- Nature & weather ---
  {en:"rain", ph:"/reɪn/", bn:"বৃষ্টি", pos:"noun", cat:"Nature", ex:"The rain stopped at noon.", exBn:"দুপুরে বৃষ্টি থামলো।"},
  {en:"sun", ph:"/sʌn/", bn:"সূর্য", pos:"noun", cat:"Nature", ex:"The sun rises in the east.", exBn:"সূর্য পূর্ব দিগন্তে ওঠে।"},
  {en:"moon", ph:"/muːn/", bn:"চাঁদ", pos:"noun", cat:"Nature", ex:"The moon looks beautiful tonight.", exBn:"আজ রাতে চাঁদ সুন্দর লাগছে।"},
  {en:"sky", ph:"/skaɪ/", bn:"আকাশ", pos:"noun", cat:"Nature", ex:"The sky is clear today.", exBn:"আজ আকাশ পরিষ্কার।"},
  {en:"tree", ph:"/triː/", bn:"গাছ", pos:"noun", cat:"Nature", ex:"This tree is very old.", exBn:"এই গাছটা খুব পুরনো।"},
  {en:"river", ph:"/ˈrɪvər/", bn:"নদী", pos:"noun", cat:"Nature", ex:"The river flows fast.", exBn:"নদীটা দ্রুত বয়ে যায়।"},
  {en:"sea", ph:"/siː/", bn:"সমুদ্র", pos:"noun", cat:"Nature", ex:"We visited the sea last year.", exBn:"গত বছর আমরা সমুদ্রে গিয়েছিলাম।"},
  {en:"weather", ph:"/ˈweðər/", bn:"আবহাওয়া", pos:"noun", cat:"Nature", ex:"The weather is nice today.", exBn:"আজ আবহাওয়া সুন্দর।"},
  {en:"cold", ph:"/koʊld/", bn:"ঠান্ডা", pos:"adjective", cat:"Nature", ex:"Winter is very cold here.", exBn:"এখানে শীত খুব ঠান্ডা।"},
  {en:"hot", ph:"/hɒt/", bn:"গরম", pos:"adjective", cat:"Nature", ex:"Today is very hot.", exBn:"আজ খুব গরম।"},

  // --- Technology ---
  {en:"phone", ph:"/foʊn/", bn:"ফোন / মোবাইল", pos:"noun", cat:"Technology", ex:"My phone battery is low.", exBn:"আমার ফোনের ব্যাটারি কম।"},
  {en:"computer", ph:"/kəmˈpjuːtər/", bn:"কম্পিউটার", pos:"noun", cat:"Technology", ex:"I work on a computer.", exBn:"আমি কম্পিউটারে কাজ করি।"},
  {en:"internet", ph:"/ˈɪntərnet/", bn:"ইন্টারনেট", pos:"noun", cat:"Technology", ex:"The internet is slow today.", exBn:"আজ ইন্টারনেট ধীর।"},
  {en:"message", ph:"/ˈmesɪdʒ/", bn:"বার্তা / মেসেজ", pos:"noun", cat:"Technology", ex:"I sent you a message.", exBn:"আমি তোমাকে একটা মেসেজ পাঠিয়েছি।"},
  {en:"email", ph:"/ˈiːmeɪl/", bn:"ইমেইল", pos:"noun", cat:"Technology", ex:"Check your email please.", exBn:"অনুগ্রহ করে তোমার ইমেইল চেক করো।"},
  {en:"photo", ph:"/ˈfoʊtoʊ/", bn:"ছবি", pos:"noun", cat:"Technology", ex:"Take a photo of us.", exBn:"আমাদের একটা ছবি তোলো।"},
  {en:"video", ph:"/ˈvɪdioʊ/", bn:"ভিডিও", pos:"noun", cat:"Technology", ex:"This video went viral.", exBn:"ভিডিওটা ভাইরাল হয়ে গেছে।"},
  {en:"website", ph:"/ˈwebsaɪt/", bn:"ওয়েবসাইট", pos:"noun", cat:"Technology", ex:"This website is helpful.", exBn:"এই ওয়েবসাইটটা সাহায্য করে।"},

  // --- Advanced ---
  {en:"achieve", ph:"/əˈtʃiːv/", bn:"অর্জন করা", pos:"verb", cat:"Advanced", ex:"You can achieve your dream.", exBn:"তুমি তোমার স্বপ্ন অর্জন করতে পারো।"},
  {en:"confident", ph:"/ˈkɒnfɪdənt/", bn:"আত্মবিশ্বাসী", pos:"adjective", cat:"Advanced", ex:"Be confident in the exam.", exBn:"পরীক্ষায় আত্মবিশ্বাসী হও।"},
  {en:"decision", ph:"/dɪˈsɪʒən/", bn:"সিদ্ধান্ত", pos:"noun", cat:"Advanced", ex:"It was a hard decision.", exBn:"এটা কঠিন একটা সিদ্ধান্ত ছিল।"},
  {en:"opportunity", ph:"/ˌɒpərˈtuːnəti/", bn:"সুযোগ", pos:"noun", cat:"Advanced", ex:"This is a great opportunity.", exBn:"এটা একটা দারুণ সুযোগ।"},
  {en:"success", ph:"/səkˈses/", bn:"সফলতা", pos:"noun", cat:"Advanced", ex:"Success needs hard work.", exBn:"সফলতার জন্য কঠোর পরিশ্রম লাগে।"},
  {en:"failure", ph:"/ˈfeɪljər/", bn:"ব্যর্থতা", pos:"noun", cat:"Advanced", ex:"Failure teaches us a lot.", exBn:"ব্যর্থতা আমাদের অনেক কিছু শেখায়।"},
  {en:"improve", ph:"/ɪmˈpruːv/", bn:"উন্নতি করা", pos:"verb", cat:"Advanced", ex:"Practice improves your skill.", exBn:"অভ্যাস তোমার দক্ষতা বাড়ায়।"},
  {en:"knowledge", ph:"/ˈnɒlɪdʒ/", bn:"জ্ঞান", pos:"noun", cat:"Advanced", ex:"Books give us knowledge.", exBn:"বই আমাদের জ্ঞান দেয়।"},
  {en:"experience", ph:"/ɪkˈspɪriəns/", bn:"অভিজ্ঞতা", pos:"noun", cat:"Advanced", ex:"Tell us about your experience.", exBn:"আপনার অভিজ্ঞতা বলুন।"},
  {en:"responsible", ph:"/rɪˈspɒnsəbl/", bn:"দায়িত্বশীল", pos:"adjective", cat:"Advanced", ex:"He is a responsible person.", exBn:"সে একজন দায়িত্বশীল মানুষ।"},
  {en:"environment", ph:"/ɪnˈvaɪrənmənt/", bn:"পরিবেশ", pos:"noun", cat:"Advanced", ex:"We must protect the environment.", exBn:"আমাদের পরিবেশ রক্ষা করা উচিত।"},
  {en:"technology", ph:"/tekˈnɒlədʒi/", bn:"প্রযুক্তি", pos:"noun", cat:"Advanced", ex:"Technology is changing fast.", exBn:"প্রযুক্তি দ্রুত বদলাচ্ছে।"},
  {en:"communicate", ph:"/kəˈmjuːnɪkeɪt/", bn:"যোগাযোগ করা", pos:"verb", cat:"Advanced", ex:"We communicate in English.", exBn:"আমরা ইংরেজিতে যোগাযোগ করি।"},
  {en:"necessary", ph:"/ˈnesəseri/", bn:"প্রয়োজনীয়", pos:"adjective", cat:"Advanced", ex:"Sleep is necessary for health.", exBn:"স্বাস্থ্যের জন্য ঘুম প্রয়োজনীয়।"},
  {en:"important", ph:"/ɪmˈpɔːrtnt/", bn:"গুরুত্বপূর্ণ", pos:"adjective", cat:"Advanced", ex:"Health is important.", exBn:"স্বাস্থ্য গুরুত্বপূর্ণ।"}
];

// ------------------------- SHORTCUTS -------------------------
const DEFAULT_SHORTCUTS = [
  {en:"I'm going to...", bn:"আমি যাচ্ছি... / আমি ... করতে যাচ্ছি", tip:"\"I'm going to eat\" = আমি খেতে যাচ্ছি। পরিকল্পনা বোঝাতে ব্যবহার হয়।", cat:"Daily"},
  {en:"I gotta...", bn:"আমাকে ... করতেই হবে (গোটা = got to)", tip:"\"I gotta go\" = আমাকে যেতে হবে। বন্ধুদের সাথে কথা বলার সময়।", cat:"Daily"},
  {en:"Kinda...", bn:"একটু / মোটামুটি (kinda = kind of)", tip:"\"It's kinda cold\" = একটু ঠান্ডা।", cat:"Daily"},
  {en:"Lemme...", bn:"আমাকে দাও / দিতে দাও (lemme = let me)", tip:"\"Lemme see\" = দেখতে দাও।", cat:"Daily"},
  {en:"Wanna...?", bn:"করতে চাও? (wanna = want to)", tip:"\"Wanna go out?\" = বের হতে চাও?", cat:"Daily"},
  {en:"Dunno", bn:"জানি না (dunno = don't know)", tip:"\"I dunno\" = জানি না।", cat:"Daily"},
  {en:"Gimme...", bn:"আমাকে দাও (gimme = give me)", tip:"\"Gimme a minute\" = এক মিনিট দাও।", cat:"Daily"},
  {en:"Outta...", bn:"বাইরে থেকে / শেষ (outta = out of)", tip:"\"Get outta here!\" = এখান থেকে বের হও!", cat:"Daily"},
  {en:"Gotta bounce", bn:"তাহলে যাই / ছাড়ছি", tip:"বন্ধুত্বপূর্ণ বিদায়। \"It's late, gotta bounce!\"", cat:"Slang"},
  {en:"Hang out", bn:"অলস সময় কাটানো / ঘুরে বেড়ানো", tip:"\"Let's hang out this weekend\" = চলো এই সপ্তাহান্তে ঘুরে আসি।", cat:"Phrases"},
  {en:"No worries", bn:"কোনো সমস্যা নেই / ঠিক আছে", tip:"কাউকে sorry বললে \"No worries!\" দিয়ে উত্তর দিতে পারেন।", cat:"Phrases"},
  {en:"What's up?", bn:"কী অবস্থা? / কী খবর?", tip:"বন্ধুদের জন্য hello-র মতো। উত্তর: \"Not much!\"", cat:"Phrases"},
  {en:"Sounds good", bn:"ঠিক আছে / ভালো শোনাচ্ছে", tip:"প্রস্তাব মেনে নেওয়ার সহজ উপায়।", cat:"Phrases"},
  {en:"I'm on it", bn:"আমি কাজটা শুরু করে দিয়েছি", tip:"কাজ নিতে রাজি হওয়ার জন্য।", cat:"Work"},
  {en:"Let me know", bn:"আমাকে জানাবেন", tip:"\"Let me know if you need help.\" = দরকার হলে জানাবেন।", cat:"Work"},
  {en:"By the way (BTW)", bn:"যাইহোক / কথার মাঝে", tip:"নতুন কোনো কথা শুরু করতে।", cat:"Work"},
  {en:"ASAP (as soon as possible)", bn:"যত তাড়াতাড়ি সম্ভব", tip:"\"Send it ASAP\" = তাড়াতাড়ি পাঠাও।", cat:"Work"},
  {en:"Deal with it", bn:"সামলে নেওয়া", tip:"\"I'll deal with it\" = আমি সামলে নেবো।", cat:"Work"}
];

// ------------------------- LESSONS -------------------------
// Structure: {id, level, title, intro, words:[{en, bn}], examples:[{en, bn}], quiz:[{q, opts, a}]}
const DEFAULT_LESSONS = [
  // ===== BEGINNER =====
  {id:"b1", level:"beginner", title:"পরিচয় — নিজের কথা বলা",
   intro:"সবার প্রথম কাজ নিজেকে পরিচয় করিয়ে দেওয়া শেখা। এই ক্লাস শেষে আপনি ইংরেজিতে নিজের নাম, বয়স আর কাজ বলতে পারবেন।",
   words:[{en:"name", bn:"নাম"},{en:"age", bn:"বয়স"},{en:"live", bn:"থাকা"},{en:"student", bn:"ছাত্র"},{en:"job", bn:"চাকরি"}],
   rules:[
     {en:"I am [name].", bn:"আমি [নাম]। — যেমন: I am Rahim."},
     {en:"I am [number] years old.", bn:"আমি [সংখ্যা] বছরের। — I am 20 years old."},
     {en:"I live in [place].", bn:"আমি [জায়গায়] থাকি। — I live in Dhaka."},
     {en:"I am a [job/student].", bn:"আমি একজন [পেশা/ছাত্র]। — I am a student."}
   ],
   quiz:[
     {q:"\"I am a student\" এর বাংলা কী?", opts:["আমি একজন ছাত্র।","আমি পড়া শুনি।","আমি স্কুলে যাই।"], a:0},
     {q:"\"আমি ঢাকায় থাকি\" — ইংরেজি কোনটি?", opts:["I go to Dhaka.","I live in Dhaka.","I like Dhaka."], a:1},
     {q:"বয়স বলতে কোনটি সঠিক?", opts:["I have 20 years.","I am 20 years old.","My age goes 20."], a:1}
   ]},
  {id:"b2", level:"beginner", title:"অভিবাদন — দৈনন্দিন কথাসাপ্তাহিক",
   intro:"Hello, Hi, Good morning — এই ক্লাসে শিখবেন কীভাবে বিভিন্ন সময়ে মানুষকে অভিবাদন জানাবেন এবং উত্তর দেবেন।",
   words:[{en:"greet", bn:"অভিবাদন জানানো"},{en:"morning", bn:"সকাল"},{en:"afternoon", bn:"দুপুর"},{en:"evening", bn:"সন্ধ্যা"},{en:"fine", bn:"ভালো"}],
   rules:[
     {en:"Good morning (সকাল), Good afternoon (দুপুর), Good evening (সন্ধ্যা)", bn:"সময় অনুযায়ী অভিবাদন বদলায়। রাতে ঘুমানোর আগে: Good night।"},
     {en:"How are you? — I'm fine, thank you.", bn:"কেমন আছো? — আমি ভালো, ধন্যবাদ। এটাই সবচেয়ে সাধারণ উত্তর।"},
     {en:"Nice to meet you!", bn:"প্রথম পরিচয়ে বলুন। উত্তর দিন: Nice to meet you too!"}
   ],
   quiz:[
     {q:"সকালে কাউকে দেখে কী বলবেন?", opts:["Good night","Good morning","Good bye"], a:1},
     {q:"\"How are you?\" এর উত্তর কোনটি?", opts:["I'm fine, thank you.","I am 20.","Yes, please."], a:0},
     {q:"রাতে ঘুমানোর আগে কী বলে?", opts:["Good evening","Good night","Good morning"], a:1}
   ]},
  {id:"b3", level:"beginner", title:"পরিবার ও আত্মীয়",
   intro:"পরিবারের সদস্যদের ইংরেজি নাম আর তাদের নিয়ে ছোট ছোট বাক্য শিখুন।",
   words:[{en:"family", bn:"পরিবার"},{en:"parents", bn:"বাবা-মা"},{en:"brother", bn:"ভাই"},{en:"sister", bn:"বোন"},{en:"son", bn:"ছেলে"},{en:"daughter", bn:"মেয়ে"}],
   rules:[
     {en:"I have two brothers and one sister.", bn:"আমার দুই ভাই আর এক বোন আছে।"},
     {en:"This is my father. He is a farmer.", bn:"ইনি আমার বাবা। তিনি কৃষক।"},
     {en:"My family is small/big.", bn:"আমার পরিবার ছোট/বড়।"}
   ],
   quiz:[
     {q:"\"parents\" মানে কী?", opts:["পরিবার","বাবা-মা","আত্মীয়"], a:1},
     {q:"\"আমার এক বোন আছে\" — কোনটি সঠিক?", opts:["I am one sister.","I have one sister.","I with one sister."], a:1},
     {q:"daughter কাকে বলে?", opts:["ছেলে সন্তান","মেয়ে সন্তান","নাতনি"], a:1}
   ]},
  {id:"b4", level:"beginner", title:"সংখ্যা ও দাম কেনাকাটা",
   intro:"১ থেকে ১০০ পর্যন্ত সংখ্যা আর দোকানে দাম জিজ্ঞেস করার বাক্য শিখুন।",
   words:[{en:"price", bn:"দাম"},{en:"cost", bn:"মূল্য (হওয়া)"},{en:"buy", bn:"কেনা"},{en:"cheap", bn:"সস্তা"},{en:"expensive", bn:"দামি"}],
   rules:[
     {en:"How much is this?", bn:"এটার দাম কত? — কেনাকাটার সবচেয়ে দরকারি বাক্য!"},
     {en:"It costs 200 taka.", bn:"এটার দাম ২০০ টাকা।"},
     {en:"That's too expensive.", bn:"এটা তো খুব দামি।"}
   ],
   quiz:[
     {q:"দাম জানতে চাইলে কী বলবেন?", opts:["What is this?","How much is this?","Where is this?"], a:1},
     {q:"\"cheap\" এর অর্থ?", opts:["দামি","সস্তা","ভালো"], a:1},
     {q:"\"It costs 50 taka\" মানে?", opts:["এটা ৫০ টাকায় বিক্রি হয়","এটার দাম ৫০ টাকা","৫০ টাকা দিয়েছি"], a:1}
   ]},
  {id:"b5", level:"beginner", title:"খাবার ও রেস্টুরেন্ট",
   intro:"খাবারের নাম আর রেস্টুরেন্টে অর্ডার করার বাক্য শিখুন — I'd like... থেকে The bill, please পর্যন্ত।",
   words:[{en:"order", bn:"অর্ডার করা"},{en:"menu", bn:"মেনু"},{en:"bill", bn:"বিল"},{en:"tasty", bn:"সুস্বাদু"},{en:"hungry", bn:"ক্ষুধার্ত"}],
   rules:[
     {en:"I'd like a chicken burger, please.", bn:"আমি একটা চিকেন বার্গার নিতে চাই। (I'd like = আমি চাই, ভদ্র উপায়)"},
     {en:"Can I have the menu?", bn:"মেনুটা পাবো?"},
     {en:"The bill, please.", bn:"বিলটা দিন, প্লিজ।"}
   ],
   quiz:[
     {q:"অর্ডার দিতে কোনটি সবচেয়ে ভদ্র?", opts:["Give me food!","I'd like a coffee, please.","Food now."], a:1},
     {q:"\"bill\" মানে কী?", opts:["খাবার","বিল/হিসাব","টিপস"], a:1},
     {q:"খিদা পেলে কী বলবেন?", opts:["I am hungry.","I am thirsty.","I am tired."], a:0}
   ]},

  // ===== INTERMEDIATE =====
  {id:"i1", level:"inter", title:"অতীত কাল — Past Simple",
   intro:"গতকাল কী করেছিলেন সেটা বলতে Past tense লাগবে। went, ate, saw — এই ক্লাসে শিখুন কীভাবে অতীতের ঘটনা বলবেন।",
   words:[{en:"went (go→went)", bn:"গিয়েছিলাম"},{en:"ate (eat→ate)", bn:"খেয়েছিলাম"},{en:"saw (see→saw)", bn:"দেখেছিলাম"},{en:"did (do→did)", bn:"করেছিলাম"},{en:"yesterday", bn:"গতকাল"}],
   rules:[
     {en:"I went to the market yesterday.", bn:"আমি গতকাল বাজারে গিয়েছিলাম।"},
     {en:"She ate rice with fish.", bn:"সে ভাতের সাথে মাছ খেয়েছিল।"},
     {en:"Did you watch the match?", bn:"তুমি কি ম্যাচটা দেখেছিলে? — প্রশ্ন করতে Did ব্যবহার হয়।"}
   ],
   quiz:[
     {q:"\"আমি গতকাল সিনেমা দেখেছি\" — সঠিক বাক্য?", opts:["I watch a movie yesterday.","I watched a movie yesterday.","I watching a movie yesterday."], a:1},
     {q:"go-এর past form কোনটি?", opts:["goed","gone","went"], a:2},
     {q:"প্রশ্ন করতে কোনটি সঠিক?", opts:["Did you went?","Did you go?","Do you went?"], a:1}
   ]},
  {id:"i2", level:"inter", title:"ভবিষ্যৎ কাল — পরিকল্পনা বলা",
   intro:"আগামীকাল, পরের সপ্তাহে কী করবেন — will আর going to দিয়ে ভবিষ্যৎ বলতে শিখুন।",
   words:[{en:"will", bn:"হবে (ভবিষ্যৎ)"},{en:"plan", bn:"পরিকল্পনা"},{en:"next week", bn:"পরের সপ্তাহ"},{en:"soon", bn:"শীঘ্রই"},{en:"later", bn:"পরে"}],
   rules:[
     {en:"I will call you tomorrow.", bn:"আমি আগামীকাল তোমাকে ফোন করবো।"},
     {en:"I'm going to visit Cox's Bazar next week.", bn:"পরের সপ্তাহে আমি কক্সবাজার যাবো।"},
     {en:"We'll see later.", bn:"পরে দেখা যাবে।"}
   ],
   quiz:[
     {q:"কাল ফোন করবো — কোনটি সঠিক?", opts:["I will call you tomorrow.","I call you tomorrow.","I called you tomorrow."], a:0},
     {q:"পরিকল্পনা বোঝাতে কোনটি বেশি ভালো?", opts:["going to","will have","was to"], a:0},
     {q:"\"We'll\" এর পূর্ণরূপ?", opts:["We well","We will","We shall not"], a:1}
   ]},
  {id:"i3", level:"inter", title:"দৈনিক রুটিন — Present Simple",
   intro:"প্রতিদিন যা করেন তা বলতে present simple। সকালে ঘুম থেকে ওঠা থেকে রাতে ঘুমানো পর্যন্ত রুটিন বলতে শিখুন।",
   words:[{en:"usually", bn:"সাধারণত"},{en:"always", bn:"সবসময়"},{en:"never", bn:"কখনো না"},{en:"wake up", bn:"ঘুম থেকে ওঠা"},{en:"routine", bn:"দৈনন্দিন কাজ"}],
   rules:[
     {en:"I wake up at 7 every day.", bn:"আমি প্রতিদিন সকাল ৭টায় ঘুম থেকে উঠি।"},
     {en:"She goes to work by bus.", bn:"সে বাসে করে কাজে যায়। (তার সাথে ক্রিয়ায় s/es)"},
     {en:"I never eat fast food.", bn:"আমি কখনো ফাস্টফুড খাই না।"}
   ],
   quiz:[
     {q:"\"সে স্কুলে যায়\" — সঠিক বাক্য?", opts:["She go to school.","She goes to school.","She going to school."], a:1},
     {q:"\"always\" এর বাংলা?", opts:["কখনো না","সবসময়","মাঝে মাঝে"], a:1},
     {q:"আমি সকাল ৬টায় উঠি — কোনটি?", opts:["I wake up at 6.","I woke up at 6.","I waking up at 6."], a:0}
   ]},
  {id:"i4", level:"inter", title:"চাকরির ভাইভা — নিজেকে উপস্থাপন",
   intro:"চাকরির ইন্টারভিউতে যেসব বাক্য দরকার — Tell me about yourself থেকে I'm a quick learner পর্যন্ত।",
   words:[{en:"experience", bn:"অভিজ্ঞতা"},{en:"skill", bn:"দক্ষতা"},{en:"responsible", bn:"দায়িত্বশীল"},{en:"team", bn:"দল"},{en:"strength", bn:"শক্তি/দক্ষতা"}],
   rules:[
     {en:"I have three years of experience in sales.", bn:"আমার সেলসে তিন বছরের অভিজ্ঞতা আছে।"},
     {en:"I'm a quick learner and hard-working.", bn:"আমি দ্রুত শিখি এবং পরিশ্রমী।"},
     {en:"I can work well in a team.", bn:"আমি দলে ভালোভাবে কাজ করতে পারি।"}
   ],
   quiz:[
     {q:"অভিজ্ঞতা বলতে কোনটি সঠিক?", opts:["I have 2 years experience.","I have 2 years of experience.","I am 2 years experienced."], a:1},
     {q:"দ্রুত শেখা বোঝাতে?", opts:["I'm a quick learner.","I learn quickful.","I am quick learn."], a:0},
     {q:"\"team\" মানে?", opts:["একা কাজ","দল","প্রতিযোগিতা"], a:1}
   ]},
  {id:"i5", level:"inter", title:"অভিমত দেওয়া ও নেওয়া",
   intro:"I think..., In my opinion... — নিজের মত প্রকাশ করতে আর অন্যের মতের সাথে দ্বিমত করতে শিখুন।",
   words:[{en:"opinion", bn:"মতামত"},{en:"agree", bn:"একমত"},{en:"disagree", bn:"দ্বিমত"},{en:"maybe", bn:"হয়তো"},{en:"certainly", bn:"অবশ্যই"}],
   rules:[
     {en:"In my opinion, English is very useful.", bn:"আমার মতে, ইংরেজি খুব কাজের।"},
     {en:"I agree with you.", bn:"আমি আপনার সাথে একমত।"},
     {en:"I'm sorry, but I disagree.", bn:"দুঃখিত, কিন্তু আমি একমত নই। — ভদ্রভাবে দ্বিমত।"}
   ],
   quiz:[
     {q:"নিজের মত বলতে?", opts:["In my opinion...","You are wrong.","Nobody cares."], a:0},
     {q:"একমত হলে বলবেন?", opts:["I disagree.","I agree with you.","I don't care."], a:1},
     {q:"\"maybe\" এর অর্থ?", opts:["অবশ্যই","হয়তো","কখনোই না"], a:1}
   ]},

  // ===== ADVANCED =====
  {id:"a1", level:"adv", title:"Present Perfect — অভিজ্ঞতা বলা",
   intro:"I have done it! এই কাল দিয়ে বলেন এমন কাজ যা সবে সম্পন্ন হয়েছে বা জীবনে কখনো করেছেন। have/has + ক্রিয়ার past participle।",
   words:[{en:"have done", bn:"করেছি"},{en:"already", bn:"ইতিমধ্যে"},{en:"yet", bn:"এখনো"},{en:"ever", bn:"কখনো (জীবনে)"},{en:"never", bn:"কখনোই না"}],
   rules:[
     {en:"I have finished my homework.", bn:"আমি আমার হোমওয়ার্ক শেষ করেছি।"},
     {en:"Have you ever been to London?", bn:"তুমি কি কখনো লন্ডন গিয়েছো?"},
     {en:"She has already eaten.", bn:"সে ইতিমধ্যে খেয়ে ফেলেছে।"}
   ],
   quiz:[
     {q:"সঠিক বাক্য কোনটি?", opts:["I have went there.","I have gone there.","I has gone there."], a:1},
     {q:"\"আমি কখনোই জাপান যাইনি\"?", opts:["I never went Japan.","I have never been to Japan.","I did never go Japan."], a:1},
     {q:"already এর ব্যবহার কোনটি?", opts:["She has already left.","She already has leave.","She already left has."], a:0}
   ]},
  {id:"a2", level:"adv", title:"শর্তসাপেক্ষ বাক্য — Conditionals",
   intro:"If দিয়ে শর্ত: If I had money, I would travel. এই ক্লাসে শিখুন স্বপ্ন, সম্ভাবনা আর শর্ত বোঝানোর ইংরেজি।",
   words:[{en:"if", bn:"যদি"},{en:"would", bn:"হতো (শর্তসাপেক্ষ)"},{en:"could", bn:"পারতাম"},{en:"unless", bn:"যদি না"},{en:"chance", bn:"সুযোগ"}],
   rules:[
     {en:"If I had money, I would travel the world.", bn:"যদি আমার টাকা থাকত, আমি পৃথিবী ঘুরে বেড়াতাম। (স্বপ্ন/অসম্ভব শর্ত)"},
     {en:"If it rains, I will stay home.", bn:"যদি বৃষ্টি হয়, আমি বাড়িতে থাকবো। (সম্ভাব্য শর্ত)"},
     {en:"I would help you if I could.", bn:"পারলে তোমাকে সাহায্য করতাম।"}
   ],
   quiz:[
     {q:"সম্ভাব্য শর্ত কোনটি?", opts:["If I were you...","If it rains, I will stay.","If I had known..."], a:1},
     {q:"\"If I were you, I would study.\" মানে?", opts:["তুমি আমি হলে পড়তে","আমি তুমি হলে পড়তাম","তুমি আমার মতো পড়ো"], a:1},
     {q:"\"unless\" মানে?", opts:["যদি","যদি না","কারণ"], a:1}
   ]},
  {id:"a3", level:"adv", title:"ফরমাল ইংরেজি — অফিসিয়াল ইমেইল",
   intro:"কাজের ইমেইল, আবেদনপত্র লেখার ভাষা — Dear Sir থেকে Best regards পর্যন্ত প্রফেশনাল ইংরেজি।",
   words:[{en:"regarding", bn:"সংক্রান্ত"},{en:"attached", bn:"সংযুক্ত"},{en:"request", bn:"অনুরোধ"},{en:"sincerely", bn:"বিনীত"},{en:"deadline", bn:"শেষ সময়সীমা"}],
   rules:[
     {en:"Dear Sir/Madam, I am writing regarding the position...", bn:"সম্ভাষণ দিয়ে শুরু করে লেখার উদ্দেশ্য বলুন।"},
     {en:"Please find the report attached.", bn:"রিপোর্টটি সংযুক্ত করা হলো।"},
     {en:"I look forward to hearing from you. Best regards,", bn:"আপনার উত্তরের অপেক্ষায়। বিনীত,"}
   ],
   quiz:[
     {q:"ইমেইল শুরু করার ফরমাল উপায়?", opts:["Hey!","Dear Sir/Madam,","Yo, boss!"], a:1},
     {q:"ফাইল সংযুক্ত করা বোঝাতে?", opts:["Please find attached...","Look the file.","File here you see."], a:0},
     {q:"ইমেইলের শেষ কীভাবে করবেন?", opts:["Bye bye!","Best regards,","That's all."], a:1}
   ]},
  {id:"a4", level:"adv", title:"Phrasal Verbs — আসল ইংরেজির চাবিকাঠি",
   intro:"give up, look after, put off — এই ছোট ছোট কম্বিনেশন শিখলে ইংরেজিতে নেটিভদের মতো কথা বলা সহজ হবে।",
   words:[{en:"give up", bn:"হাল ছাড়া"},{en:"look after", bn:"দেখাশোনা করা"},{en:"put off", bn:"পিছিয়ে দেওয়া"},{en:"find out", bn:"খুঁজে বের করা"},{en:"carry on", bn:"চালিয়ে যাওয়া"}],
   rules:[
     {en:"Never give up on your dreams.", bn:"কখনো তোমার স্বপ্ন ছেড়ো না।"},
     {en:"Can you look after my cat?", bn:"আমার বিড়ালটার দেখাশোনা করবেন?"},
     {en:"The meeting was put off until Friday.", bn:"মিটিং শুক্রবার পর্যন্ত পিছিয়ে দেওয়া হয়েছে।"}
   ],
   quiz:[
     {q:"\"give up\" মানে?", opts:["দেওয়া উপরে","হাল ছাড়া","উপরে তোলা"], a:1},
     {q:"দেখাশোনা করা বোঝাতে?", opts:["look after","look at","look up"], a:0},
     {q:"খুঁজে বের করা = ?", opts:["find out","put off","give in"], a:0}
   ]},
  {id:"a5", level:"adv", title:"বর্ণনা করা — Describing People & Places",
   intro:"কাউকে বা কোনো জায়গাকে সুন্দরভাবে বর্ণনা করতে adjective আর বাক্য গঠন শিখুন।",
   words:[{en:"appearance", bn:"চেহারা"},{en:"personality", bn:"ব্যক্তিত্ব"},{en:"lively", bn:"প্রাণবন্ত"},{en:"crowded", bn:"ভিড়ে ভরা"},{en:"peaceful", bn:"শান্তিপূর্ণ"}],
   rules:[
     {en:"He is tall, friendly and very hard-working.", bn:"সে লম্বা, বন্ধুসুলভ এবং খুব পরিশ্রমী।"},
     {en:"Dhaka is a busy but lively city.", bn:"ঢাকা একটা ব্যস্ত কিন্তু প্রাণবন্ত শহর।"},
     {en:"The village is peaceful, especially at dawn.", bn:"গ্রামটা শান্তিপূর্ণ, বিশেষ করে ভোরবেলা।"}
   ],
   quiz:[
     {q:"মানুষের ব্যক্তিত্ব বোঝাতে কোনটি?", opts:["He is tall.","He is honest and kind.","He is in Dhaka."], a:1},
     {q:"\"crowded\" মানে?", opts:["জনশূন্য","ভিড়ে ভরা","পরিষ্কার"], a:1},
     {q:"শহর বর্ণনায় কোনটি সঠিক?", opts:["Dhaka is busy city.","Dhaka is a busy city.","Dhaka is the busy city."], a:1}
   ]}
];

// ------------------------- PRACTICE SCENARIOS -------------------------
const DEFAULT_SCENARIOS = [
  {id:"rest", icon:"🍽️", title:"Restaurant", sub:"রেস্টুরেন্টে অর্ডার করা",
   prompt:"Welcome to Green Restaurant! 🍽️ I'm your waiter. What would you like to order today?",
   hints:["I'd like a chicken burger, please.","Can I see the menu?","The bill, please."],
   aiNote:"You are a friendly restaurant waiter. The user is a Bangladeshi English learner practicing ordering food. Ask natural questions about their order, suggest items, keep it short (1-2 sentences). Correct gently if they make mistakes."},
  {id:"shop", icon:"🛍️", title:"Shopping", sub:"দোকানে কেনাকাটা",
   prompt:"Hello! Welcome to our shop! 🛍️ How can I help you today?",
   hints:["How much is this shirt?","Do you have a smaller size?","I'm just looking, thanks."],
   aiNote:"You are a shopkeeper. The user is a Bangladeshi English learner practicing shopping conversations. Talk about prices, sizes, colors. Keep it short. Correct gently if needed."},
  {id:"interv", icon:"💼", title:"Job Interview", sub:"চাকরির ভাইভা",
   prompt:"Good morning! Please have a seat. I'm the hiring manager. Let's start — tell me about yourself.",
   hints:["I'm a hard-working person.","I have 2 years of experience.","I'm a quick learner."],
   aiNote:"You are a job interviewer at a company. The user is a Bangladeshi English learner practicing interview skills. Ask common interview questions: strengths, weaknesses, experience, goals. Keep it short and encouraging."},
  {id:"doctor", icon:"🩺", title:"At the Doctor", sub:"ডাক্তারের কাছে",
   prompt:"Hello! I'm Dr. Rahman. What seems to be the problem today?",
   hints:["I have a fever.","I have a headache since yesterday.","My stomach hurts."],
   aiNote:"You are a doctor. The user is a Bangladeshi English learner practicing describing health problems. Ask about symptoms, give simple advice. Keep it short. Correct gently."},
  {id:"travel", icon:"✈️", title:"Travel & Airport", sub:"ভ্রমণ ও এয়ারপোর্ট",
   prompt:"Good morning! Welcome to the airport help desk. ✈️ Where are you flying today?",
   hints:["I want to book a ticket to Dubai.","Where is gate 5?","I lost my luggage."],
   aiNote:"You are an airport staff member. The user is a Bangladeshi English learner practicing travel English. Help with tickets, gates, luggage. Keep it short. Correct gently."},
  {id:"free", icon:"💬", title:"Free Talk", sub:"যেকোনো বিষয়ে আলাপ",
   prompt:"Hi there! 👋 I'm your English practice partner. Let's chat about anything — hobbies, movies, food, dreams! What do you want to talk about?",
   hints:["Let's talk about cricket!","I love biryani!","What's your favorite movie?"],
   aiNote:"You are a friendly conversation partner. The user is a Bangladeshi English learner practicing free conversation. Ask follow-up questions about their interests. Keep it short. Correct mistakes gently."}
];

// ------------------------- KIDS CONTENT -------------------------
const KIDS_LETTERS = [
  {l:"A", word:"Apple", bn:"আপেল (আম কুড়ি নয়!)", emoji:"🍎", phon:"A for Apple"},
  {l:"B", word:"Ball", bn:"বল", emoji:"⚽", phon:"B for Ball"},
  {l:"C", word:"Cat", bn:"বিড়াল", emoji:"🐱", phon:"C for Cat"},
  {l:"D", word:"Dog", bn:"কুকুর", emoji:"🐶", phon:"D for Dog"},
  {l:"E", word:"Elephant", bn:"হাতি", emoji:"🐘", phon:"E for Elephant"},
  {l:"F", word:"Fish", bn:"মাছ", emoji:"🐟", phon:"F for Fish"},
  {l:"G", word:"Goat", bn:"ছাগল", emoji:"🐐", phon:"G for Goat"},
  {l:"H", word:"Hat", bn:"টুপি", emoji:"👒", phon:"H for Hat"},
  {l:"I", word:"Ice cream", bn:"আইসক্রিম", emoji:"🍦", phon:"I for Ice cream"},
  {l:"J", word:"Jug", bn:"জগ", emoji:"🫗", phon:"J for Jug"},
  {l:"K", word:"Kite", bn:"ঘুড়ি", emoji:"🪁", phon:"K for Kite"},
  {l:"L", word:"Lion", bn:"সিংহ", emoji:"🦁", phon:"L for Lion"},
  {l:"M", word:"Moon", bn:"চাঁদ", emoji:"🌙", phon:"M for Moon"},
  {l:"N", word:"Nest", bn:"পাখির বাসা", emoji:"🪺", phon:"N for Nest"},
  {l:"O", word:"Orange", bn:"কমলা", emoji:"🍊", phon:"O for Orange"},
  {l:"P", word:"Parrot", bn:"টিয়া পাখি", emoji:"🦜", phon:"P for Parrot"},
  {l:"Q", word:"Queen", bn:"রানী", emoji:"👑", phon:"Q for Queen"},
  {l:"R", word:"Rain", bn:"বৃষ্টি", emoji:"🌧️", phon:"R for Rain"},
  {l:"S", word:"Sun", bn:"সূর্য", emoji:"☀️", phon:"S for Sun"},
  {l:"T", word:"Tiger", bn:"বাঘ", emoji:"🐯", phon:"T for Tiger"},
  {l:"U", word:"Umbrella", bn:"ছাতা", emoji:"☂️", phon:"U for Umbrella"},
  {l:"V", word:"Van", bn:"ভ্যান গাড়ি", emoji:"🚐", phon:"V for Van"},
  {l:"W", word:"Watch", bn:"ঘড়ি", emoji:"⌚", phon:"W for Watch"},
  {l:"X", word:"Xylophone", bn:"বাদ্যযন্ত্র", emoji:"🎹", phon:"X for Xylophone"},
  {l:"Y", word:"Yak", bn:"ভেড়ার মতো পশু", emoji:"🐂", phon:"Y for Yak"},
  {l:"Z", word:"Zebra", bn:"জেব্রা", emoji:"🦓", phon:"Z for Zebra"}
];

const KID_FIRST_WORDS = [
  {en:"apple", bn:"আপেল", emoji:"🍎"},{en:"ball", bn:"বল", emoji:"⚽"},
  {en:"cat", bn:"বিড়াল", emoji:"🐱"},{en:"dog", bn:"কুকুর", emoji:"🐶"},
  {en:"sun", bn:"সূর্য", emoji:"☀️"},{en:"moon", bn:"চাঁদ", emoji:"🌙"},
  {en:"star", bn:"তারা", emoji:"⭐"},{en:"fish", bn:"মাছ", emoji:"🐟"},
  {en:"bird", bn:"পাখি", emoji:"🐦"},{en:"duck", bn:"হাঁস", emoji:"🦆"},
  {en:"cow", bn:"গরু", emoji:"🐄"},{en:"milk", bn:"দুধ", emoji:"🥛"},
  {en:"cake", bn:"কেক", emoji:"🎂"},{en:"car", bn:"গাড়ি", emoji:"🚗"},
  {en:"bus", bn:"বাস", emoji:"🚌"},{en:"book", bn:"বই", emoji:"📖"},
  {en:"pen", bn:"কলম", emoji:"🖊️"},{en:"tree", bn:"গাছ", emoji:"🌳"},
  {en:"flower", bn:"ফুল", emoji:"🌸"},{en:"house", bn:"বাড়ি", emoji:"🏠"}
];

const KID_GAMES = [
  {id:"pickword", icon:"🎯", title:"ভেজাল মেলাও!", sub:"ছবি দেখে সঠিক শব্দ বাছাই করো"},
  {id:"abcsong", icon:"🎵", title:"ABC শেখো", sub:"A থেকে Z — প্রতিটা অক্ষর ছবি ও শব্দসহ"}
];

// ------------------------- AI / SYSTEM -------------------------
const GROQ_MODELS = {
  chat:"llama-3.3-70b-versatile",
  stt:"whisper-large-v3-turbo"
};
